package com.PUCE.chuldeteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChuldetecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
