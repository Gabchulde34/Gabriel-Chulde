package com.PUCE.chuldeteca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChuldetecaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChuldetecaApplication.class, args);
	}

}
